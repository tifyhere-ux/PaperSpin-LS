# PaperSpin-LS

PaperSpin-LS is a prototype-ready concept for an ultra-low-cost 3D laser scanner
designed to make 3D scanning accessible to students, hobbyists, and small studios.

The project focuses on reducing hardware cost and complexity by using
passive rotation and basic laser triangulation instead of motors and encoders.

---

## Project Overview
PaperSpin-LS uses:
- A single line laser
- A fixed camera (USB or smartphone)
- A passively rotating turntable
- Software-based reconstruction

The system captures depth slices as the object rotates and reconstructs
a 3D point cloud that can be exported as `.STL` or `.PLY`.

---

## Repository Structure
- `cad/` – CAD models and exploded views
- `docs/` – Design, assembly, and calibration documentation
- `bom/` – Bill of materials and cost breakdown
- `diagrams/` – System and hardware diagrams
- `software/` – Reconstruction workflow and algorithms

---

## Status
This repository contains a **design-complete, prototype-ready concept**
intended for open-source replication and further development.

---

## License
MIT License
