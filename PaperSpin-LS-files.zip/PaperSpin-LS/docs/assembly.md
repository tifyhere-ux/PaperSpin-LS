# Assembly Guide

1. 3D print enclosure and turntable components
2. Mount the line laser at a fixed angle
3. Secure the camera facing the scanning area
4. Install passive rotation mechanism (elastic band or gravity weight)
5. Verify laser alignment before calibration
