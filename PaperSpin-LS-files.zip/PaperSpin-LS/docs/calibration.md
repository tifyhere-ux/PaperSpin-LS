# Calibration Methodology

Calibration is performed using a known reference object.

Steps:
1. Capture laser line on a flat surface
2. Measure pixel displacement
3. Estimate baseline and focal parameters
4. Store calibration constants for reconstruction
