# Digital Scanning Workflow

1. Capture video during object rotation
2. Extract frames
3. Detect laser line per frame
4. Compute depth using triangulation
5. Estimate rotation angle visually
6. Generate point cloud
7. Export mesh as STL or PLY
