# System Overview

PaperSpin-LS is designed as a low-cost laser triangulation scanner.
The system minimizes electronics by relying on passive mechanics
and software-based interpretation.

Core subsystems:
- Optical (laser + camera)
- Mechanical (turntable + enclosure)
- Software (image processing and reconstruction)
