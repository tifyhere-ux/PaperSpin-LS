# Reconstruction Pipeline

The reconstruction process is software-driven and based on
laser triangulation principles.

Planned tools:
- Python
- OpenCV
- NumPy

Output formats:
- STL
- PLY
